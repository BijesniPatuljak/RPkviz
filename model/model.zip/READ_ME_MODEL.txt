/model

>user.class je k
>quiz.class je k
>question.class je k
>ponudjeni_odgovor.class je k
>result.class je k

<>QuizService.class je under construction
